package com.tcc.metodologiasageis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MetodologiasAgeisApplication {

	public static void main(String[] args) {
		SpringApplication.run(MetodologiasAgeisApplication.class, args);
	}

}
